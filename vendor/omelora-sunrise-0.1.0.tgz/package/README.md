# Sunrise

Omelora's shared design system — colors, spacing, typography, radii, shadows, and core UI components.

Designed to be reused across Bridge, Activities, and future Omelora web apps.

## Structure

```
src/
  theme.ts              # Design tokens (Hack Club–style single config)
  tailwind-preset.ts    # Tailwind theme wiring for consuming apps
  lib/cn.ts             # Tiny className helper
  components/
    Button.tsx
    Card.tsx
    Badge.tsx
    Input.tsx
    PageShell.tsx
  index.ts              # Public exports
```

## Usage (local package)

In a sibling app (`bridge`, `activities`, etc.):

```json
{
  "dependencies": {
    "@omelora/sunrise": "file:../sunrise"
  }
}
```

Wire tokens into Tailwind:

```ts
// tailwind.config.ts
import type { Config } from "tailwindcss";
import { sunrisePreset } from "@omelora/sunrise";

const config: Config = {
  presets: [sunrisePreset],
  content: ["./src/**/*.{ts,tsx}", "../sunrise/src/**/*.{ts,tsx}"],
};

export default config;
```

Import components:

```tsx
import { Button, Card, Badge, Input, PageShell } from "@omelora/sunrise";
```

## Notes

- Hex values in `theme.ts` are placeholders. Swap them once you pull exact brand colors from Zite.
- `PageShell` is a layout shell (sidebar slot + header slot + main), not a full nav implementation.
- Keep this package lean; publish to npm later when Bridge/Activities are ready to share it.
# sunrise
