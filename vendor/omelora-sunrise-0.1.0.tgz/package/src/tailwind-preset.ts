import { theme } from "./theme";

/**
 * Tailwind preset for Sunrise tokens.
 * Consuming apps: presets: [sunrisePreset]
 */
export const sunrisePreset = {
  theme: {
    extend: {
      colors: {
        sunrise: theme.colors.sunrise,
        pink: theme.colors.pink,
        navy: theme.colors.navy,
        background: theme.colors.background,
        foreground: theme.colors.foreground,
        muted: {
          DEFAULT: theme.colors.muted,
          foreground: theme.colors.mutedForeground,
        },
        border: theme.colors.border,
        ring: theme.colors.ring,
        destructive: {
          DEFAULT: theme.colors.destructive,
          foreground: theme.colors.destructiveForeground,
        },
        card: {
          DEFAULT: theme.colors.card,
          foreground: theme.colors.cardForeground,
        },
        primary: {
          DEFAULT: theme.colors.sunrise[500],
          foreground: "#202124",
        },
        secondary: {
          DEFAULT: theme.colors.pink[500],
          foreground: "#FFFFFF",
        },
        accent: {
          DEFAULT: theme.colors.navy[800],
          foreground: "#FFFFFF",
        },
      },
      spacing: theme.space,
      fontSize: theme.fontSizes,
      fontWeight: theme.fontWeights,
      fontFamily: {
        sans: [...theme.fonts.sans],
        mono: [...theme.fonts.mono],
      },
      borderRadius: theme.radii,
      boxShadow: theme.shadows,
      backgroundImage: {
        "sunrise-gradient": theme.sunriseGradient,
      },
    },
  },
} as const;

export default sunrisePreset;
