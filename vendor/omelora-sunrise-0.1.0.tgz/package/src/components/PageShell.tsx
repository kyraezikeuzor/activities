import * as React from "react";
import { cn } from "../lib/cn";

export interface PageShellProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional left sidebar (desktop). Pass your app nav here. */
  sidebar?: React.ReactNode;
  /** Optional top header / mobile nav. */
  header?: React.ReactNode;
  /** Constrain main content width. Default: true */
  constrain?: boolean;
}

/**
 * App layout shell: optional sidebar + header + main content area.
 * Does not implement navigation itself — slots are for app-specific chrome.
 */
export const PageShell = React.forwardRef<HTMLDivElement, PageShellProps>(
  (
    { className, sidebar, header, constrain = true, children, ...props },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={cn("min-h-screen bg-background text-foreground", className)}
        {...props}
      >
        <div className="flex min-h-screen">
          {sidebar ? (
            <div className="hidden md:block shrink-0">{sidebar}</div>
          ) : null}

          <div className="flex min-w-0 flex-1 flex-col">
            {header ? <div className="shrink-0">{header}</div> : null}

            <main
              className={cn(
                "flex-1 w-full",
                constrain && "mx-auto max-w-4xl px-4 sm:px-6"
              )}
            >
              {children}
            </main>
          </div>
        </div>
      </div>
    );
  }
);

PageShell.displayName = "PageShell";

export default PageShell;
