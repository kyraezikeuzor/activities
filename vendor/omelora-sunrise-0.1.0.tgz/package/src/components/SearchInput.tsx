import * as React from "react";
import { cn } from "../lib/cn";

export interface SearchInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  "aria-label": string;
}

/** Quiet discovery field. Its accessible name is required even without a visible label. */
export const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  ({ className, ...props }, ref) => (
    <div className="relative w-full">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-foreground">
        <circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4.5 4.5" />
      </svg>
      <input {...props} ref={ref} type="search" className={cn("h-12 w-full rounded-full border-0 bg-[#f5f5f5] pl-12 pr-5 text-base font-normal text-foreground placeholder:text-neutral-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutral-500 disabled:opacity-50", className)} />
    </div>
  )
);
SearchInput.displayName = "SearchInput";
