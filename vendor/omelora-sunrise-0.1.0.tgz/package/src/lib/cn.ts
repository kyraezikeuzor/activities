type ClassValue = string | false | null | undefined;

/** Tiny className combiner — no external dependency. */
export function cn(...classes: ClassValue[]): string {
  return classes.filter(Boolean).join(" ");
}
