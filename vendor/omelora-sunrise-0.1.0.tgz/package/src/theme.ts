/**
 * Sunrise design tokens
 */

export const gradient = {
  pastelOrange: "#FDB575",
  yellow: "#FBE274",
  peachRed: "#FE9D7F",
  redPeachy: "#FF7B69",
} as const;

/**
 * Multi-point mesh gradient for page backgrounds.
 * Use as a CSS background-image value, or via Tailwind `bg-sunrise-gradient`.
 */
export const sunriseGradient = [
  `radial-gradient(ellipse at 0% 0%, ${gradient.pastelOrange} 0%, transparent 55%)`,
  `radial-gradient(ellipse at 100% 0%, ${gradient.yellow} 0%, transparent 50%)`,
  `radial-gradient(ellipse at 0% 100%, ${gradient.peachRed} 0%, transparent 55%)`,
  `radial-gradient(ellipse at 5% 95%, ${gradient.redPeachy} 0%, transparent 40%)`,
].join(", ");

export const colors = {
  // Brand
  sunrise: {
    50: "#FFF9F2",
    100: "#FFF0E0",
    200: "#FFE2C0",
    300: "#FFCD93",
    400: "#FFB45D",
    500: "#FF971E", // primary button / brand orange
    600: "#D77D19",
    700: "#B36515",
    800: "#924F11",
    900: "#793E0E",
  },
  pink: {
    50: "#FDF2F8",
    100: "#FCE7F3",
    200: "#FBCFE8",
    300: "#F9A8D4",
    400: "#F472B6",
    500: "#EC4899",
    600: "#DB2777",
    700: "#BE185D",
    800: "#9D174D",
    900: "#831843",
  },
  navy: {
    50: "#F8FAFC",
    100: "#F1F5F9",
    200: "#E2E8F0",
    300: "#CBD5E1",
    400: "#94A3B8",
    500: "#64748B",
    600: "#475569",
    700: "#334155",
    800: "#1E293B",
    900: "#0F172A",
  },

  // Semantic aliases
  background: "#FFFFFF",
  foreground: "#202124",
  muted: "#F7F7F5",
  mutedForeground: "#666A73",
  border: "#E7E7E4",
  ring: "#525252",
  destructive: "#EF4444",
  destructiveForeground: "#FAFAFA",
  card: "#FFFFFF",
  cardForeground: "#1F1F1F",
} as const;

export const space = {
  0: "0px",
  1: "4px",
  2: "8px",
  3: "12px",
  4: "16px",
  5: "20px",
  6: "24px",
  8: "32px",
  10: "40px",
  12: "48px",
  16: "64px",
} as const;

export const fontSizes = {
  xs: "0.75rem",
  sm: "0.875rem",
  base: "1rem",
  lg: "1.125rem",
  xl: "1.25rem",
  "2xl": "1.5rem",
  "3xl": "1.875rem",
  "4xl": "2.25rem",
} as const;

export const fontWeights = {
  normal: "400",
  medium: "500",
  semibold: "600",
  bold: "700",
} as const;

export const fonts = {
  sans: ['Inter', 'Helvetica Neue', 'ui-sans-serif', 'system-ui', 'sans-serif'],
  mono: ['Fira Code', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
} as const;

export const radii = {
  none: "0px",
  sm: "0.25rem",
  md: "0.375rem",
  lg: "0.5rem",
  xl: "0.75rem",
  "2xl": "1rem",
  full: "9999px",
} as const;

export const shadows = {
  sm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
  DEFAULT: "0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)",
  md: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
  lg: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
} as const;

export const theme = {
  colors,
  gradient,
  sunriseGradient,
  space,
  fontSizes,
  fontWeights,
  fonts,
  radii,
  shadows,
} as const;

export type SunriseTheme = typeof theme;

export default theme;
